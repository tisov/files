import Vue from 'vue'
import VueRouter from 'vue-router'
import store from '../store/store'
import fb from 'firebase/app'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'home',
    component: () => import('@/views/Home')
  },
  {
    path: '/ad/:id',
    name: 'ad',
    props: true,
    component: () => import('@/views/Ad')
  },
  {
    path: '/adlist',
    name: 'adList',
    meta: { auth: true },
    component: () => import('@/views/AdList')
  },
  {
    path: '/new-ad',
    name: 'newAd',
    meta: { auth: true },
    component: () => import('@/views/NewAd')
  },
  {
    path: '/orders',
    name: 'orders',
    meta: { auth: true },
    component: () => import('@/views/Orders')
  },
  {
    path: '/login',
    name: 'signIn',
    component: () => import('@/components/auth/SignIn')
  },
  {
    path: '/register',
    name: 'register',
    component: () => import('@/components/auth/Register')
  },
]

let router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

router.beforeEach((to, from, next) => {
  let isRequireAuth = to.matched.some(route => route.meta.auth)
  if (!fb.auth().currentUser && isRequireAuth) {
    next('/login')
  } else {
    next()
  }
})

export default router
