export default {
  data() {
    return {
      emailRules: [
        v => !!v || 'E-mail is required',
        v => /.+@.+\..+/.test(v) || 'E-mail must be valid',
      ],
      passwordRules: [
        v => !!v || 'Password is required',
        v => (v && v.length >= 6) || 'Password must be more than 6 characters',
      ],
      passwordConfirmRules: [
        v => !!v || 'Password is required',
        v => v === this.password || 'Password should match',
      ],
      titleRules: [
        v => !!v || 'Title is required',
        v => (v && v.length >= 1) || 'Title too short',
      ],
      descriptionRules: [
        v => !!v || 'Description is required',
        v => (v && v.length >= 6) || 'Description too short',
      ]
    }
  }
}