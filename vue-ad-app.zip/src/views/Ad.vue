<template>
  <v-container v-if="!loading">
    <v-row justify="center">
      <v-col >
        <v-card
          class="mx-auto"
          max-width="600"
        >
          <v-img
            class="white--text align-end"
            height="200px"
            :src="ad.imageSrc"
          >
            <v-card-title>{{ad.title}}</v-card-title>
          </v-img>

          <v-card-text class="text--primary">
            <div>{{ad.description}}</div>
          </v-card-text>

          <v-card-actions>
            <v-btn color="orange" text @click="dialog=true"
              v-if="isOwner"
            >
              edit
            </v-btn>
            <v-btn color="primary">
              buy
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-col>
    </v-row>
    <ad-edit v-model="dialog" :ad="ad"></ad-edit>
  </v-container>
</template>

<!-- ------------------------------------- -->
<script>
import adEdit from '@/components/adEdit'

export default {
  props: ['id'],
  data() {
    return {
      dialog: false
    }
  },
  computed: {
    ad() {
      return this.$store.getters.getAdById(this.id)
    },
    loading() {
      return this.$store.getters.loading
    },
    isOwner() {
      return this.ad.ownerId === this.$store.getters.getUserId
    }
  },
  components: {
    adEdit
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>