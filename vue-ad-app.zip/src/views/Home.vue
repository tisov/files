<template>
  <div class="home">
    <!-- ads slider -->
    <v-container>
      <v-carousel :height="carouselHeight">
        <v-carousel-item
          v-for="ad in promoAds"
          :key="ad.id"
          :src="ad.imageSrc"
        >
          <div class="car-ad-link">
            <v-btn :to="`/ad/${ad.id}`"
              color="secondary" tile 
            >{{ad.title}}</v-btn>
          </div>
        </v-carousel-item>
      </v-carousel>
    </v-container>
    <!-- ads cards -->
    <v-container >
      <h2 class="headline mt-4">Recent ads</h2>
      <hr>
      <v-row >
        <v-col sm="6" md="4" lg="3"
           v-for="ad in ads" :key="ad.adId"
        >
          <v-card class="mx-auto" max-width="400">
            <v-img
              class="white--text align-end"
              height="200px"
              :src="ad.imageSrc"
            >
              <v-card-title>{{ad.title}}</v-card-title>
            </v-img>

            <v-card-text class="text--primary">
              {{ad.description}}
            </v-card-text>

            <v-card-actions>
              <v-btn text :to="`/ad/${ad.adId}`">
                open
              </v-btn>
              
              <v-btn color="primary" outlined
                @click="buyAction(ad)"
              >
                buy
              </v-btn>
              
            </v-card-actions>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
    <ad-buy-modal v-model="modal"
      :ad="modalAd"
    ></ad-buy-modal>
  </div>
</template>

<!-- ------------------------------------- -->
<script>
import adBuyModal from '@/components/adBuyModal'

export default {
  data() {
    return {
      modal: false,
      modalAd: {}
    }
  },
  computed: {
    carouselHeight() {
      return this.$vuetify.breakpoint.xs ? 200 : 400
    },
    ads() {
      return this.$store.getters.getAds
    },
    promoAds() {
      return this.$store.getters.getPromoAds
    }
  },
  methods: {
    buyAction(ad) {
      this.modalAd = ad
      this.modal = true
    }
  },
  created() {
    // this.carouselHeight = 50
  },
  components: {
    adBuyModal
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>
.car-ad-link
  position: absolute
  bottom: 50px
  left: 50%
  transform: translate(-50%, 0)
  background: rgba(0, 0, 0, 0.5)
</style>