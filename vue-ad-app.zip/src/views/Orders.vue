<template>
  <v-container>
    <v-row justify="center">
      <v-col sm="6">
        <v-list flat subheader>
          <v-subheader class="subtitle-1">My orders</v-subheader>

          <v-list-item v-for="order in orders" :key="order.orderId">
            <v-list-item-action>
              <v-checkbox @click.stop="markDone(order)"
                color="primary"
                :input-value="order.done"
              ></v-checkbox>
            </v-list-item-action>

            <v-list-item-content>
              <v-list-item-title>{{order.owner}}</v-list-item-title>
              <v-list-item-subtitle>{{order.phone}}</v-list-item-subtitle>
            </v-list-item-content>
            
            <v-list-item-action>
              <v-btn color="primary"
                :to="`/ad/${order.adId}`"
              >open</v-btn>
            </v-list-item-action>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
  </v-container>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  data() {
    return {
      orders: [
        { orderId: 1, adId: 2, owner: 'James', phone: '99-1-222-22-22', done: false }
      ]
    }
  },
  methods: {
    markDone(order) {
      order.done = true
    }
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>