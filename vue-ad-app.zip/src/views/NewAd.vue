<template>
  <v-container>
    <v-row justify="center">
      <v-col sm="6" md="4" >
        <v-form ref="form" v-model="valid" lazy-validation>
          <h3 class="primary white--text px-2 font-weight-medium">
            Add new ad
          </h3>
          
          <v-text-field
            v-model="title"
            :rules="titleRules"
            label="Ad title"
            class="mb-4"
          ></v-text-field>
          
          <v-textarea
            v-model="description"
            label="Description"
            :rules="descriptionRules"
            height="80px"
          ></v-textarea>
          
          <v-btn color="blue-grey" class="ma-2 white--text d-block ml-0"
            @click="$refs.fileInput.click()"
          >
            Upload
            <v-icon right dark>mdi-cloud-upload</v-icon>
          </v-btn>
          
          <input type="file" @input="fileHandler"
            style="display:none;" ref="fileInput"
          >
          
          <v-img :src="imageSrc"
            ref="image"
            height="100"
            class="mb-4"
          ></v-img>
          
          <v-switch v-model="promo"
            label="Add to promo?"
          ></v-switch>
          
          <v-btn
            :disabled="!valid || loading"
            color="primary"
            class="mr-4"
            @click="onSubmit"
          >
            Submit
          </v-btn>
        </v-form>
      </v-col>
    </v-row>
  </v-container>
</template>

<!-- ------------------------------------- -->
<script>
import validationRules from '@/mixins/validationRules'

export default {
  mixins: [validationRules],
  data() {
    return {
      valid: false,
      title: 'qwe',
      description: 'qweasdzxc',
      promo: false,
      imageSrc: '',
      imageFile: null
    }
  },
  computed: {
    loading() {
      return this.$store.getters.loading
    }
  },
  methods: {
    async onSubmit() {
      if (this.$refs.form.validate() && this.imageSrc) {
        const formData = {
          title: this.title,
          description: this.description,
          promo: this.promo,
          imageFile: this.imageFile,
          imageSrc: ''
        }
        try {
          await this.$store.dispatch('createAd', formData)
          this.$router.push('/adlist')
        } catch (err) {

        }
      }
    },
    fileHandler(e) {
      let file = e.target.files[0]
      this.imageFile = file
      this.imageSrc = URL.createObjectURL(file)
    }
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>