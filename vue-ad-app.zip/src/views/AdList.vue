<template>
  <v-container>
    <v-row justify="center">
      <v-col sm="8" md="6">
        <h2 class="headline">My ads list</h2>
        <v-card v-for="ad in myAds" :key="ad.id"
          class="mx-auto mb-3"
          max-width="400"
          outlined
        >
          <v-list-item>
            <v-list-item-content class="pt-0">
              <v-list-item-title class="subtitle-1 mb-1 font-weight-medium">
                {{ad.title}}
              </v-list-item-title>
              <v-list-item-subtitle>
                {{ad.description}}
              </v-list-item-subtitle>
            </v-list-item-content>

            <v-list-item-avatar
              tile
              size="80"
              color="grey"
            >
              <v-img :src="ad.imageSrc"></v-img>
            </v-list-item-avatar>
          </v-list-item>

          <v-card-actions>
            <v-btn text outlined color="primary"
              :to="`/ad/${ad.id}`"
            >open</v-btn>
          </v-card-actions>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  data() {
    return {

    }
  },
  computed: {
    myAds() {
      return this.$store.getters.getMyAds
    }
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass' scoped>
.headline
  max-width: 400px
  margin-left: auto
  margin-right: auto
  margin-bottom: 1rem
</style>