<template>
  <v-app>
    <nav-drawer v-model="drawer" 
      :links="links"
    ></nav-drawer>

    <app-bar v-model="drawer" @input="drawer = !drawer"
      :links="links"
    ></app-bar>

    <v-content>
      <router-view />
    </v-content>
    
    <v-footer color="primary">
      <span class="white--text">&copy; 2020</span>
    </v-footer>
    
    <v-snackbar v-model="snackbar">
      {{ errorText }}
    </v-snackbar>
  </v-app>
</template>

<!-- ------------------------------------- -->
<script>
import NavDrawer from './components/NavDrawer'
import AppBar from './components/AppBar'

export default {
  data() {
    return {
      drawer: false,
      snackbar: false,
      errorText: ''
    }
  },
  computed: {
    error() {
      return this.$store.getters.error
    },
    isLoggedIn() {
      return this.$store.getters.isLoggedIn
    },
    links() {
      const linksLocal = [
        { title: 'Sign in', icon: 'mdi-lock', url: '/login' },
        { title: 'Register', icon: 'mdi-face', url: '/register' },
        { title: 'Orders', icon: 'mdi-bookmark-outline', url: '/orders', auth: true },
        { title: 'New ad', icon: 'mdi-note-outline', url: '/new-ad', auth: true },
        { title: 'My ads', icon: 'mdi-format-list-bulleted', url: '/adlist', auth: true }
      ]
      if (this.isLoggedIn) {
        return linksLocal.filter(link => link.auth)
      } else {
        return linksLocal.filter(link => !link.auth)
      }
    }
  },
  watch: {
    error(val) {
      if (val) {
        this.snackbar = true
        this.errorText = val
        this.$store.commit('clearError')
      }
    }
  },
  created() {
    this.$store.dispatch('fetchAds')
  },
  components: {
    NavDrawer,
    AppBar
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>
.container
  max-width: 1200px !important
</style>