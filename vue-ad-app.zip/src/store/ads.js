import fb from 'firebase/app'

export default {
  state: {
    ads: []
  },
  mutations: {
    setAd(state, payload) {
      state.ads.push(payload)
    },
    updateAd(state, payload) {
      const ad = state.ads.find(ad => ad.adId === payload.adId)
      ad.title = payload.title
      ad.description = payload.description
      debugger
    }
  },
  actions: {
    // Update ad
    async updateAd({ commit }, payload) {
      commit('clearError')
      commit('setLoading')

      try {
        await fb.database().ref(`/ads/${payload.adId}`).update({
          title: payload.title,
          description: payload.description
        })
        commit('updateAd', payload)
      } catch (err) {
        commit('setError', err)
        throw err
      } finally {
        commit('clearLoading')
      }
    },
    // Create ad
    async createAd({ commit, getters }, payload) {
      commit('clearError')
      commit('setLoading')
      try {
        const userId = getters.getUserId
        const imageExt = payload.imageFile.name.slice(
          payload.imageFile.name.lastIndexOf('.')
        )
        const res = await fb.database().ref(`/ads`).push({
          title: payload.title,
          description: payload.description,
          promo: payload.promo,
          imageSrc: payload.imageSrc,
          ownerId: userId
        })

        const imageResponse = await fb.storage().ref(`/ads/${res.key}.${imageExt}`)
          .put(payload.imageFile)
        await fb.database().ref(`/ads/${res.key}`).update({
          imageSrc: imageResponse.downloadURL
        })
        commit('setAd', {
          ...payload,
          adId: res.key,
          imageSrc: imageResponse.downloadURL
        })
      } catch (err) {
        commit('setError', err)
        throw err
      } finally {
        commit('clearLoading')
      }
    },
    // Fetch ads
    async fetchAds({ commit }) {
      commit('clearError')
      commit('setLoading')
      try {
        const snapshot = await fb.database().ref('/ads').once('value')
        snapshot.forEach(childSnap => {
          commit('setAd', {
            ...childSnap.val(),
            adId: childSnap.key
          })
        })
      } catch (err) {
        commit('setError', err)
        throw err
      } finally {
        commit('clearLoading')
      }
    }
  },
  getters: {
    getAds: state => state.ads,
    getPromoAds: state => {
      return state.ads.filter(ad => ad.promo)
    },
    getMyAds: (state, getters) => {
      return state.ads.filter(ad => {
        return ad.ownerId === getters.getUserId
      })
    },
    getAdById: state => {
      return adId => state.ads.find(ad => ad.adId === adId)
    }
  }
}