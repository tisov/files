import fb from 'firebase/app'

export default {
  state: {
    userId: null
  },
  mutations: {
    setUser(state, payload) {
      state.userId = payload
    }
  },
  actions: {
    // Register
    async createUser({ commit }, payload) {
      commit('clearError')
      commit('setLoading')
      try {
        const user = await fb.auth().createUserWithEmailAndPassword(
          payload.email,
          payload.password
        )
        commit('setUser', user.uid)
      } catch (err) {
        commit('setError', err.message)
        throw err
      }
      commit('clearLoading')
    },
    // Sign in
    async signIn({ commit }, payload) {
      commit('clearError')
      commit('setLoading')
      try {
        const user = await fb.auth().signInWithEmailAndPassword(
          payload.email,
          payload.password
        )
        commit('setUser', user.uid)
      } catch (err) {
        commit('setError', err.message)
        throw err
      } finally {
        commit('clearLoading')
      }
    },
    // Sign out
    async signOut({ commit }) {
      await fb.auth().signOut()
      commit('setUser', null)
    }
  },
  getters: {
    getUserId: state => state.userId,
    isLoggedIn: state => state.userId !== null
  }
}