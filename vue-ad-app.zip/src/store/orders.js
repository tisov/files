import fb from 'firebase/app'

export default {
  state: {
    orders: []
  },
  mutations: {
    setOrder(state, payload) {
      state.orders.push(payload)
    }
  },
  actions: {
    async createOrder({ commit }, payload) {

    }
  },
  getters: {

  }
}