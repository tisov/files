import Vue from 'vue'
import Vuex from 'vuex'
import ads from './ads'
import loader from './loader'
import auth from './auth'
import orders from './orders'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
  },
  mutations: {
  },
  actions: {
  },
  modules: {
    ads,
    auth,
    loader,
    orders
  }
})
