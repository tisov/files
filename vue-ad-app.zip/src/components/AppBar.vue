<template>
  <v-app-bar app color="primary" dark dense>
    <v-app-bar-nav-icon @click.stop="$emit('input')" 
      class="d-md-none"
    />
    <v-toolbar-title>
      <router-link to="/" active-class="">Application</router-link>
    </v-toolbar-title>
    <v-spacer></v-spacer>
    <v-btn text v-for="link in links"
      :to="link.url"
      class="d-none d-md-flex"
    >
      <v-icon left>{{link.icon}}</v-icon>
      <span>{{link.title}}</span>
    </v-btn>
    <!-- logout btn -->
    <v-btn class="d-none d-md-flex"
      v-if="isLoggedIn"
      text
      @click="signOut"
    >
      <v-icon left>mdi-exit-to-app</v-icon>
      <span>log out</span>
    </v-btn>
  </v-app-bar>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  props: ['value', 'links'],
  data() {
    return {

    }
  },
  computed: {
    isLoggedIn() {
      return this.$store.getters.isLoggedIn
    }
  },
  methods: {
    async signOut() {
      await this.$store.dispatch('signOut')
      this.$route.path !== '/' && this.$router.push('/')
    }
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>
.v-toolbar__title a
  color: inherit !important
  text-decoration: none
</style>