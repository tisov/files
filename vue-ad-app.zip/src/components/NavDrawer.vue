<template>
  <v-navigation-drawer app 
    :value="value" @input="$emit('input', $event)"
  >
    <v-list>
      <v-list-item v-for="link in links" 
        :key="link.title"
        :to="link.url"
      >
        <v-list-item-icon>
          <v-icon color="primary">{{link.icon}}</v-icon>
        </v-list-item-icon>

        <v-list-item-content>
          <v-list-item-title v-text="link.title"></v-list-item-title>
        </v-list-item-content>
      </v-list-item>
      
      <v-list-item v-if="isLoggedIn" @click="signOut">
        <v-list-item-icon>
          <v-icon color="primary">mdi-exit-to-app</v-icon>
        </v-list-item-icon>
        <v-list-item-content>
          <v-list-item-title v-text="'Log out'"></v-list-item-title>
        </v-list-item-content>
      </v-list-item>
    </v-list>
  </v-navigation-drawer>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  props: ['value', 'links'],
  data() {
    return {

    }
  },
  computed: {
    isLoggedIn() {
      return this.$store.getters.isLoggedIn
    }
  },
  methods: {
    async signOut() {
      await this.$store.dispatch('signOut')
      this.$route.path !== '/' && this.$router.push('/')
    }
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>