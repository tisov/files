<template>
  <v-container>
    <v-row justify="center">
      <v-col sm="6" md="4">
        <v-form ref="form" v-model="valid" lazy-validation>
          <h3 class="primary white--text px-2 font-weight-medium">Register</h3>
          
          <v-text-field
            v-model="email"
            :rules="emailRules"
            label="E-mail"
          ></v-text-field>
          
          <v-text-field
            v-model="password"
            :rules="passwordRules"
            :counter="6"
            label="Password"
          ></v-text-field>
          
          <v-text-field
            v-model="passwordConfirm"
            :rules="passwordConfirmRules"
            label="Password confirm"
            :counter="6"
          ></v-text-field>

          <v-btn
            :disabled="!valid || loading"
            color="success"
            class="mr-4"
            @click="onSubmit"
          >
            Submit
          </v-btn>
        </v-form>
      </v-col>
    </v-row>
  </v-container>
</template>

<!-- ------------------------------------- -->
<script>
import validationRules from '@/mixins/validationRules'

export default {
  mixins: [validationRules],
  data() {
    return {
      valid: false,
      email: 'qwe@mail.com',
      password: '111111',
      passwordConfirm: '111111',
    }
  },
  computed: {
    loading() {
      return this.$store.getters.loading
    },
    error() {
      return this.$store.getters.error
    }
  },
  methods: {
    async onSubmit() {
      if (this.$refs.form.validate()) {
        const formData = {
          email: this.email,
          password: this.password
        }

        try {
          await this.$store.dispatch('createUser', formData)
          this.$router.push('/')
        } catch (err) {

        }
      }
    }
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>