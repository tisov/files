<template>
  <v-row justify="center">
    <v-dialog :value="value"  persistent max-width="400px"
      @click:outside="$emit('input', false)"
    >
      <v-card>
        <v-card-title>
          <span class="subtitle-1">Ad buy</span>
        </v-card-title>
        <v-card-text class="pb-0">
          <v-row>
            <v-col cols="12" class="py-1">
              <v-text-field label="Name"
                v-model="buyerName"
              ></v-text-field>
            </v-col>
            <v-col cols="12" class="py-1">
              <v-text-field label="Phone"
                v-model="buyerPhone"
              ></v-text-field>
            </v-col>
          </v-row>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text
            @click="onCancel"
            :disabled="localLoading"
          >Close</v-btn>
          <v-btn color="blue darken-1" text
            @click="onSave"
            :loading="localLoading"
          >Save</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  props: ['value', 'ad'],
  data() {
    return {
      buyerName: '',
      buyerPhone: '',
      localLoading: false
    }
  },
  methods: {
    async onSave() {
      if (this.buyerName !== '' && this.buyerPhone !== '') {
        this.localLoading = true
        try {
          await this.$store.dispatch('createOrder', {
            buyerName,
            buyerPhone,
            adId: this.ad.adId,
            ownerId: this.ad.ownerId
          })

        } catch (err) {

        }
        this.localLoading = false
        this.$emit('input', false)
      }
    },
    onCancel() {
      this.newTitle = this.ad.title
      this.newDescription = this.ad.description
      this.$emit('input', false)
    }
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>