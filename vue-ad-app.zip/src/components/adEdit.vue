<template>
  <v-row justify="center">
    <v-dialog :value="value"  persistent max-width="600px"
      @click:outside="$emit('input', false)"
    >
      <v-card>
        <v-card-title>
          <span class="subtitle-1">Ad edit</span>
        </v-card-title>
        <v-card-text>
          <v-row>
            <v-col cols="12">
              <v-text-field label="Title"
                v-model="newTitle"
              ></v-text-field>
            </v-col>
            <v-col cols="12">
              <v-textarea v-model="newDescription"
                label="Description"
                height="80px"
              ></v-textarea>
            </v-col>
          </v-row>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text
            @click="onCancel"
          >Close</v-btn>
          <v-btn color="blue darken-1" text
            @click="onSave"
          >Save</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  props: ['value', 'ad'],
  data() {
    return {
      // title: ad.title,
      // description: ad.description,
      newTitle: this.ad.title,
      newDescription: this.ad.description
    }
  },
  methods: {
    onSave() {
      if (this.newTitle !== '' && this.newDescription !== '') {
        try {
          this.$store.dispatch('updateAd', {
            title: this.newTitle,
            description: this.newDescription,
            adId: this.ad.adId
          })

        } catch (err) {

        }
        this.$emit('input', false)
      }
    },
    onCancel() {
      this.newTitle = this.ad.title
      this.newDescription = this.ad.description
      this.$emit('input', false)
    }
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>