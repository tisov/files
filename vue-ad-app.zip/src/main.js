import Vue from 'vue'
import App from './App.vue'
import fb from 'firebase/app'
import 'firebase/auth'
import 'firebase/database'
import 'firebase/storage'
import router from './router/router'
import store from './store/store'
import vuetify from './plugins/vuetify'

Vue.config.productionTip = false

let app = null

fb.initializeApp({
  apiKey: "AIzaSyCseq4SxXg2yyZm8jO12TpnTPr54DHJwIk",
  authDomain: "ads-app-3272.firebaseapp.com",
  databaseURL: "https://ads-app-3272.firebaseio.com",
  projectId: "ads-app-3272",
  storageBucket: "ads-app-3272.appspot.com",
  messagingSenderId: "857464074908",
  appId: "1:857464074908:web:648c818ff8910a32b03359"
})

fb.auth().onAuthStateChanged(user => {
  if (!app) {
    app = new Vue({
      router,
      store,
      vuetify,
      render: function(h) { return h(App) }
    }).$mount('#app')
  }
  if (user) {
    store.commit('setUser', user.uid)
  }
})



