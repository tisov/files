/* eslint-disable no-undef */

(function ($) {
   let sportShop = {
      initialized: false,
      version: 1.0,
      mobile: false,
      windowSize: null,
      init: function () {
         if (!this.initialized) {
            this.initialized = true;
         }
         else {
            return;
         }

         /* functions initialization */
         this.scrollbar();
         this.mobileNavbarDropdown();
         this.menuDropdownWidth();
         this.mobileMenu();
         this.homeSlider();
         // this.mobileMenuBtn();
         // this.getWindowSize();
         // this.productViewSwitch();
         // this.headerCategoryMenu();
         // this.googleMap();
      },

      /* functions declaration */

      // get window width
      getWindowSize: () => {
         $(window).on('resize load', () => {
            sportShop.windowSize = $(this).outerWidth();
         });
      },

      // malihu custom scrollbar
      scrollbar: () => {
         $('.js-scrollbar').mCustomScrollbar();
      },

      // mobile navbar login/register dropdown
      mobileNavbarDropdown: () => {
         let mobileNavbar = $('.mobile-navbar'),
            dropBtns = mobileNavbar.find('.m-site-options [data-target]'),
            dropBtnClass = '.m-site-options_icon',
            isActive = false;

         dropBtns.on('click', function () {
            let targetId = $(this).data('target');

            mobileNavbar.find('.dropdown-menu').each(function () {
               if ($(this).attr('id') == targetId) {
                  $(this).toggleClass('show');
                  isActive = $(this).hasClass('show') ? true : false;
               }
               else {
                  $(this).removeClass('show');
               }
            });
         });

         // close dropdowns on document click
         $(document).on('click', function () {
            if (isActive) {
               if ($(event.target).closest(dropBtnClass).is(dropBtns)) {
                  return;
               }
               else {
                  mobileNavbar.find('.dropdown-menu').each(function () {
                     $(this).removeClass('show');
                  });
               }
            }
         });

         // close dropdown on close button click
         $('.c-search-form_close-btn').on('click', function () {
            $(this).closest('.dropdown-menu').removeClass('show');
         });
      },

      // menu dropdown container full width
      menuDropdownWidth: () => {
         $(window).on('resize load', function () {
            let container = $('.header_bottom .container').first(),
               containerWidth = container.width(),
               containerOffsetLeft = $('.container').offset().left,
               menuDropdown = $('.c-dropdown--big .c-dropdown_menu');
            console.log(containerWidth);

            menuDropdown.width(containerWidth - 90);
            menuDropdown.offset({ left: containerOffsetLeft + 15 });
         });
      },

      // mobile menu
      mobileMenu: () => {
         let menuBtn = $('.js-menu-btn'),
            bgOverlay = $('.bg-overlay'),
            menuContainer = $('.c-mmenu'),
            menuPrevBtn = menuContainer.find('.c-mmenu_prev-btn'),
            menuCloseBtn = $('.c-mmenu_close-btn'),
            desktopMenu = $('.c-menu'),
            desktopMenuLinks = desktopMenu.find('>li > a'),
            mmenuList = menuContainer.find('.c-mmenu_list'),
            mmenuListItem = '<li class="c-mmenu_list-item"></li>',
            mmenuTitle = $('.c-mmenu_menu-title'),
            submenuBtnStr = '<i class="far fa-angle-right submenu-btn"></i>',
            curMenuTitle = '',
            listItemCount = 0;
            
         // append links to mobile menu
         desktopMenuLinks.each(function () {
            let curLink = $(this).clone(),
               submenu = $(this).next('ul').clone();
            
            curLink.attr('class', 'c-mmenu_nav-link');
            curLink.children('i').remove();

            mmenuList.append(mmenuListItem)
               .children().eq(listItemCount++)
               .append(curLink);
            
            if (submenu.length) {
               curLink.append(submenuBtnStr).after(submenu);
            }
         });

         menuBtn.on('click', function () {
            menuContainer.toggleClass('show');
            bgOverlay.addClass('show');
         });

         menuCloseBtn.on('click', function () {
            menuContainer.removeClass('show');
            bgOverlay.removeClass('show');
            
         });

         $('.c-mmenu .submenu-btn').on('click', function () {
            $(this).parent().next('ul').addClass('show');
            curMenuTitle = $(this).parent().text();
            mmenuTitle.addClass('show').append(curMenuTitle);
            menuPrevBtn.addClass('show');
         });

         menuPrevBtn.on('click', function () {
            menuContainer.find('.c-dropdown_menu').removeClass('show');
            mmenuTitle.removeClass('show').empty();
            menuPrevBtn.removeClass('show');
         });

         menuContainer.on('transitionend', function () {
            if (!$(this).hasClass('show')) {
               $(this).find('.c-dropdown_menu').removeClass('show');
               mmenuTitle.removeClass('show').empty();
               menuPrevBtn.removeClass('show');
            }
         });
         
         bgOverlay.on('click', function () {
            menuContainer.removeClass('show');
            bgOverlay.removeClass('show');
         });

      },

      // home slider
      homeSlider: () => {
         $('.home-slider').slick({
            arrows: true,
            appendArrows: $('.home-slider'),
            prevArrow: '<button type="button" class="slick-prev slider-arrow slider-arrow--prev"><i class="far fa-angle-left"></i></button>',
            nextArrow: '<button type="button" class="slick-prev slider-arrow slider-arrow--next"><i class="far fa-angle-right"></i></button>'
         });  

         $('.home-products-slider').slick({
            slidesToShow: 2,
            prevArrow: '<button type="button" class="slick-prev slider-arrow slider-arrow--prev"><i class="far fa-angle-left"></i></button>',
            nextArrow: '<button type="button" class="slick-prev slider-arrow slider-arrow--next"><i class="far fa-angle-right"></i></button>',
            responsive: [
               {
                  breakpoint: 992,
                  settings: {
                     slidesToShow: 1
                  }
               }
            ]
         });
      },




      // product view switch
      productViewSwitch: () => {
         let viewBtn = $('.c-shop_view-btn');

         viewBtn.on('click', function () {
            if ($(this).hasClass('active')) {
               return;
            }

            viewBtn.removeClass('active');
            $(this).addClass('active');

            let viewMode = $(this).attr('data-show');
            let shopProductList = $('.c-shop_list');

            if (viewMode == 'grid') {
               shopProductList.removeClass('c-shop_list--list')
                  .addClass('c-shop_list--grid');
            }
            else if (viewMode == 'list') {
               shopProductList.removeClass('c-shop_list--grid')
                  .addClass('c-shop_list--list');
            }
         });
      },







      // google map
      googleMap: () => {
         if ($('#map-content').length) {
            // eslint-disable-next-line no-unused-vars
            let map = new GMaps({
               el: '#map-content',
               lat: -12.043333,
               lng: -77.028333
            });
         }
      }
   };

   /* website functions init */
   sportShop.init();


   $('.dropdown-menu').on('click', function (e) {
      e.stopPropagation();

      if ($(e.target).hasClass('nav-link')) {
         $(e.target).tab('show');
      }
   });

   $('.js-custom-checkbox').on('click', function () {
      let status = $(this).prop('checked'),
         parent = $(this).parent();

      if (status) {
         parent.addClass('checked');
      }
      else {
         parent.removeClass('checked');
      }
   });

   // eslint-disable-next-line no-undef
})(jQuery);


