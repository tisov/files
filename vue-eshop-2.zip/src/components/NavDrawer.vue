<template>
  <v-navigation-drawer app 
    :value="value" @input="$emit('input', $event)"
  >
    <v-list>
      <v-list-item v-for="link in links" 
        :key="link.title"
        :to="link.url"
      >
        <v-list-item-icon>
          <v-icon color="primary">{{link.icon}}</v-icon>
        </v-list-item-icon>

        <v-list-item-content>
          <v-list-item-title v-text="link.title"></v-list-item-title>
        </v-list-item-content>

      </v-list-item>
    </v-list>
  </v-navigation-drawer>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  props: ['value', 'links'],
  data() {
    return {

    }
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>