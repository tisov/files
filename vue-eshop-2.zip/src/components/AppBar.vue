<template>
  <v-app-bar app color="primary" dark dense>
    <v-app-bar-nav-icon @click.stop="$emit('input')" />
    <v-toolbar-title>
      <router-link to="/" active-class="">Application</router-link>
    </v-toolbar-title>
    <v-spacer></v-spacer>
    <v-btn text v-for="link in links"
      :to="link.url"
      class="d-none d-md-flex"
    >
      <v-icon left>{{link.icon}}</v-icon>
      <span>{{link.title}}</span>
    </v-btn>
  </v-app-bar>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  props: ['value', 'links'],
  data() {
    return {

    }
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>
.v-toolbar__title a
  color: inherit
  text-decoration: none
</style>