<template>
  <div class="about">
    about
  </div>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  data() {
    return {

    }
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>