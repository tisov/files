<template>
  <v-app>
    <nav-drawer v-model="drawer" 
      :links="links"
    ></nav-drawer>

    <app-bar v-model="drawer" @input="drawer = !drawer"
      :links="links"
    ></app-bar>

    <v-content>
      <router-view />
    </v-content>
    
    <v-card class="overflow-hidden">
    <v-app-bar
      absolute
      color="white"
      elevate-on-scroll
      scroll-target="#scrolling-techniques-7"
    >
      <v-app-bar-nav-icon></v-app-bar-nav-icon>

      <v-toolbar-title>Title</v-toolbar-title>

      <v-spacer></v-spacer>

      <v-btn icon>
        <v-icon>mdi-magnify</v-icon>
      </v-btn>

      <v-btn icon>
        <v-icon>mdi-heart</v-icon>
      </v-btn>

      <v-btn icon>
        <v-icon>mdi-dots-vertical</v-icon>
      </v-btn>
    </v-app-bar>
    <v-sheet
      id="scrolling-techniques-7"
      class="overflow-y-auto"
      max-height="600"
    >
      <v-container style="height: 1500px;">

      </v-container>
    </v-sheet>
  </v-card>
    
    <v-footer color="primary">
      <span class="white--text">&copy; 2020</span>
    </v-footer>
  </v-app>
</template>

<!-- ------------------------------------- -->
<script>
import NavDrawer from './components/NavDrawer'
import AppBar from './components/AppBar'

export default {
  data() {
    return {
      drawer: false,
      links: [
        { title: 'Sign in', icon: 'mdi-lock', url: '/login' },
        { title: 'Register', icon: 'mdi-face', url: '/register' },
        { title: 'Orders', icon: 'mdi-bookmark-outline', url: '/orders' },
        { title: 'New ad', icon: 'mdi-note-outline', url: '/new-ad' },
        { title: 'My ads', icon: 'mdi-format-list-bulleted', url: '/my-ads' },
      ]
    }
  },
  created() {
    console.log(this.$vuetify.breakpoint)
  },
  components: {
    NavDrawer,
    AppBar
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>
h1
  border: 1px solid red
  margin: 10px
</style>