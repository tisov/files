'use strict';

// jQuery scripts ---------------------------------------

$(document).ready(function () {

  
  
  
  //  menu slide toggle 
  $('.menu-icon').on('click', function () {
    $(this).toggleClass('anim');
    $('.header-menu ul').slideToggle('fast', function () {
      if ($(this).css('display') == 'none') {
        $(this).removeAttr('style');
      }
    });
  });

  // SECTION ONE, SLIDER
  $('.sec-one_slider').slick({
    prevArrow: '<i class="fas fa-angle-left fa-2x"></i>',
    nextArrow: '<i class="fas fa-angle-right fa-2x"></i>',
    autoplay: true
  });

  // SECTION TWO, STATISTICS COUNTER 
  $('.stat__amount').counterUp({
    delay: 20,
    time: 4000
  });
});

// Image gallery filter
$('.image-gal').filterizr({});




// JavaScript scripts -----------------------------------------


document.querySelector('#bg-video').addEventListener('canplay', function() {
  this.loop = true;
});

// Sticky nav menu customize
window.addEventListener('scroll', function () {
  var header = document.querySelector('header');
  var nav = document.querySelector('.header-nav');
  var addPadding = document.querySelector('#sec-one');

  if (pageYOffset >= header.clientHeight) {
    nav.classList.add('fixed', 'fixed-anim');
  } else {
    nav.classList.remove('fixed', 'fixed-anim');
  }
});

// Header scroll down button 
document.querySelector('.scroll-down').addEventListener('click', function () {
  var header = document.querySelector('header').clientHeight;
  var top = pageYOffset;
  var scrollAnim = setInterval(function () {
    top += 10;
    window.scrollTo(0, top);

    if (top > header) {
      clearInterval(scrollAnim);
    }
  }, 5);
});

// Google maps
function myMap() {
  var mapCanvas = document.querySelector('.g-map');
  var mapOptions = {
    center: new google.maps.LatLng(43.65, 51.15),
    zoom: 15
  };
  var map = new google.maps.Map(mapCanvas, mapOptions);
}

// Hidden container height customize
var $googleMap = $('.g-map');
var contactFormHeight = document.querySelector('.contact-form-side');
var $hidden_layer = $('.hidden');
$(window).on('resize load', function () {
  var $height = contactFormHeight.clientHeight;
  $googleMap.css('height', $height + 'px');
  $hidden_layer.css('height', $height + 'px');
});