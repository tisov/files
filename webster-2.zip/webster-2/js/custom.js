// jQuery scripts ---------------------------------------

$(document).ready(function() {
  
  // Navbar menu icon animate
  $('.navbar__icon').on('click', function() {
    $(this).toggleClass('open');
  });
  
  // Responsive menu onclick show/hide
  $('.navbar__icon').on('click', function() {
    let navbar_menu = $('.navbar__menu');
    navbar_menu.slideToggle('fast', function() {
      if( navbar_menu.css('display') == 'none' ) {
        navbar_menu.removeAttr('style');
      }
    });
  })
  
  // Fixed navbar 
  let header_height = $('#header-main').height() / 2;
  let topnav = $('.top-nav');
  
  $(window).on('scroll load', function() {
    if (pageYOffset > header_height) {
      topnav.addClass('fixed-nav');
    } else {
      topnav.removeClass('fixed-nav');
    }
  });
  
  // Video modal box
  let v_modal = $('.v-modal');
  let v_modal_content = $('.v-modal__content');
  
  $('.video-box__icon a').on('click', function() {
    event.preventDefault();
  });
  $('.video-box__icon').on('click', function() {
    let video = '<iframe height="101%" width="101%" src="https://www.youtube.com/embed/LgvseYYhqU0?autoplay=1" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>';
    v_modal_content.append(video);
    v_modal.css('display', 'flex');
    
  });
  
  // Video modal close
  $('.v-modal__close').on('click', function() {
    v_modal_content.empty();
    v_modal.css('display', 'none');
  });
  
  // product product boxes height customize
  $(window).one('load', function() {
    let elem = $('.pro-info-box');
    let parentHeight = elem.parent().css('height');
    elem.css('height', parentHeight);
  });
  
  $(window).on('scroll', function() {
    let sec_home = $('#header-main');
    let sec_about = $('#sec-one');
    let sec_feauture = $('#sec-two');
    let sec_product = $('#pro-items');
    let items = $('.navbar__menu-items ul li a');
    
    if (pageYOffset > sec_about.offset().top) {
      items.each(function() {
        
      });
    }
    console.log( sec_about.offset().top )
  });
  
  
  // product items slider
  $('.items-slider').slick({
    dots: true,
    speed: 500,
    arrows: false,
    slidesToShow: 4,
    slidesToScroll: 4,
    responsive: [
      {
        breakpoint: 991,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 575,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  });
  
  
});

  








// JavaScript scripts -----------------------------------------

























