<template>
  <v-app id="app" app>
    <!-- navigation drawer -->
    <sidenav v-model="drawer"
      :categories="categories"
      @update="contentUpdateKey++"
    ></sidenav>
    <!-- navbar -->
    <navbar v-on:drawer="drawer = !drawer"></navbar>
    
    <!-- page content -->
    <v-content :key="contentUpdateKey">
      <router-view></router-view>
      
    </v-content>
    
    <!-- footer -->
    <v-footer color="indigo">
      <span class="white--text">&copy; 2019</span>
    </v-footer>
    
  </v-app>
</template>

<!-- ------------------------------------- -->
<script>
import Navbar from '@/components/navbar'
import Sidenav from '@/components/sidenav'

export default {
  data() {
    return {
      drawer: false,
      categories: [],
      contentUpdateKey: 0
    }
  },
  async created() {
    this.categories = await this.$store.dispatch('fetchCategories')
  },
  components: {
    Navbar,
    Sidenav
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>
.btn-profile:focus:before
  opacity: 0 !important
.v-toolbar__title a
  color: inherit !important
  text-decoration: none !important
  font-size: inherit !important
  

</style>
