export default {
  computed: {
    emailErrors() {
      let errors = []
      if (this.$v.email.$dirty) {
        !this.$v.email.required && errors.push('Email is required')
        !this.$v.email.email && errors.push('Email must be valid')
        return errors
      }
      return errors
    },
    passwordErrors() {
      let errors = []
      if (this.$v.password.$dirty) {
        !this.$v.password.required && errors.push('Password is required')
        !this.$v.password.minLength && errors.push('Password must be more than 6')
        return errors
      }
      return errors
    },
    nameErrors() {
      let errors = []
      if (this.$v.name.$dirty) {
        !this.$v.name.required && errors.push('Name is required')
        return errors
      }
      return errors
    }
  }
}