import fb from 'firebase/app'

export default {
  state: {
    userId: null
  },
  mutations: {
    setUser(state, userId) {
      state.userId = userId
    },
    removeUser(state) {
      state.userId = null
    }
  },
  actions: {
    // Sign In
    async signIn({ dispatch, commit }, { email, password }) {
      try {
        const res = await fb.auth().signInWithEmailAndPassword(email, password)
        commit('setUser', res.uid)
      } catch (err) {
        throw err
      }
    },
    // Register
    async register({ dispatch, commit }, { email, password, name }) {
      try {
        const res = await fb.auth().createUserWithEmailAndPassword(email, password)
        commit('setUser', res.uid)
        await fb.database().ref(`users/${res.uid}`).set({
          name,
          address: ''
        })
      } catch (err) {
        throw err
      }
    },
    // Sign Out
    async signOut() {
      try {
        await fb.auth().signOut()
      } catch (err) {
        throw err
      }
    },
    // Get user id
    async getUserId() {
      const user = await new Promise(res => {
        fb.auth().onAuthStateChanged(user => {
          if (user) res(user.uid)
        })
      })
      return user
    }
  },
  getters: {
    getUserId(state) {
      return state.userId
    },

  }
}