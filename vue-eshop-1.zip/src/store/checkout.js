import fb from 'firebase/app'

export default {
  // Set orders
  actions: {
    async setOrder({ dispatch }, payload) {
      let userId = await dispatch('getUserId')
      payload.forEach(async product => {
        await fb.database().ref(`/users/${userId}/orders`).push({
          ...product,
          status: 'ordered',
          date: new Date().getTime()
        })
      })
    },
    // Fetch orders
    async fetchOrders({ dispatch }) {
      let orders = []
      let userId = await dispatch('getUserId')
      let snapshot = await fb.database().ref(`/users/${userId}/orders`).once('value')
      snapshot.forEach(childSnap => {
        orders.push({
          ...childSnap.val(),
          orderId: childSnap.key
        })
      })
      return orders
    }
  }

}