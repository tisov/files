import fb from 'firebase/app'

export default {
  state: {
    userName: '',
    userAddress: ''
  },
  mutations: {
    // Set user name
    setUserName(state, name) {
      state.userName = name
    },
    // Set user address
    setUserAddress(state, address) {
      state.userAddress = address
    }
  },
  actions: {
    // Fetch user data
    async fetchUserData({ dispatch, commit }) {
      const uid = await dispatch('getUserId')
      const res = await fb.database().ref(`users/${uid}`).once('value')
      return res.val()
    },
    // Fetch user name
    async fetchUserName({ dispatch, commit, getters }, payload) {
      const uid = await dispatch('getUserId')
      const res = await fb.database().ref(`users/${uid}`).once('value')
      const data = res.val()
      commit('setUserName', data.name)
    },
    // Update user name
    async updateUserName({ dispatch, commit }, newName) {
      const uid = await dispatch('getUserId')
      // const data = await dispatch('fetchUserData')
      await fb.database().ref(`users/${uid}`).update({ name: newName })
      commit('setUserName', newName)
    },
    // Fetch user address
    async fetchUserAddress({ dispatch, commit }) {
      const uid = await dispatch('getUserId')
      const res = await fb.database().ref(`users/${uid}`).once('value')
      const data = res.val()
      commit('setUserAddress', data.address)
    },
    // Update user address
    async updateUserAddress({ dispatch, commit }, newAddress) {
      const uid = await dispatch('getUserId')
      const res = await fb.database().ref(`users/${uid}`).update({
        address: newAddress
      })
      commit('setUserAddress', newAddress)
    }
  },
  getters: {
    getUserName(s) {
      return s.userName
    },
    getUserAddress: s => s.userAddress,
  }
}