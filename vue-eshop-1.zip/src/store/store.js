import Vue from 'vue'
import Vuex from 'vuex'
import auth from './auth'
import userInfo from './userInfo'
import products from './products'
import checkout from './checkout'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {

  },
  mutations: {

  },
  actions: {
  },
  getters: {
    getCategories: s => s.categories,

  },
  modules: {
    auth, userInfo, products, checkout
  }
})
