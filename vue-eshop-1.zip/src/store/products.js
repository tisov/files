import fb from 'firebase/app'

export default {
  state: {
    products: []
  },
  mutations: {
    setProducts(state, products) {
      state.products = products
    }
  },
  actions: {
    // Fetch products
    async fetchProducts({ commit }) {
      let products = []
      let res = await fb.database().ref('products').once('value')
      res.forEach(childSnapshot => {
        let value = childSnapshot.val()
        for (const key in value) {
          products.push({
            catId: childSnapshot.key,
            productId: key,
            ...value[key]
          })
        }
      })
      commit('setProducts', products)
    },
    // Fetch product by id
    async fetchProductById({ }, payload) {
      let res = await fb.database().ref(
        `/products/${payload.catId}/${payload.productId}`
      ).once('value')
      let data = res.val()
      return data
    },
    // Fetch categories
    async fetchCategories({ dispatch }) {
      let categories = []
      let res = await fb.database().ref('categories').once('value')
      res.forEach(childSnap => {
        categories.push({
          catId: childSnap.key,
          ...childSnap.val()
        })
      })
      let idx = categories.findIndex(el => el.catId === 'allItems')
      categories.push(categories.splice(idx, 1)[0])
      return categories
    },
    // Add to cart
    async addToCart({ dispatch }, payload) {
      try {
        let product = await dispatch('fetchProductById', {
          productId: payload.productId,
          catId: payload.catId
        })

        const userId = await dispatch('getUserId')
        await fb.database().ref(`/users/${userId}/cart/${payload.productId}`).set({
          ...product,
          ...payload
        })
      } catch (err) {
        throw err
      }
    },
    // Fetch cart products
    async fetchCartProducts({ dispatch }) {
      let products = []
      let userId = await dispatch('getUserId')
      let snapshot = await fb.database().ref(`/users/${userId}/cart`).once('value')
      snapshot.forEach(childSnap => {
        products.push({ ...childSnap.val() })
      })
      return products
    },
    // Delete cart product
    async deleteCartProduct({ dispatch }, productId) {
      let userId = await dispatch('getUserId')
      await fb.database().ref(`/users/${userId}/cart/${productId}`).remove()
    },
    // Clear cart
    async clearCart({ dispatch }) {
      let userId = await dispatch('getUserId')
      await fb.database().ref(`/users/${userId}/cart`).remove()
    }
  },
  getters: {
    getProducts: state => state.products,
    getProductsByCategory: state => {
      return function(catId) {
        return state.products.filter(product => product.catId === catId)
      }
    },
    getCartProducts: state => {

    }
  }
}