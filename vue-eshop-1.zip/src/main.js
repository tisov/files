import Vue from 'vue'
import App from './App.vue'
import router from './router/router'
import store from './store/store'
import fb from 'firebase/app'
import 'firebase/auth'
import 'firebase/database'
import vuetify from './plugins/vuetify'
import vuelidate from './plugins/vuelidate'
import '@babel/polyfill'

Vue.config.productionTip = false


fb.initializeApp({
  apiKey: "AIzaSyDQ7oPlBaaTb4km8Jlq4NhKbViRgXCN0hE",
  authDomain: "my-shop-app-3272.firebaseapp.com",
  databaseURL: "https://my-shop-app-3272.firebaseio.com",
  projectId: "my-shop-app-3272",
  storageBucket: "my-shop-app-3272.appspot.com",
  messagingSenderId: "520992683",
  appId: "1:520992683:web:deba80b935b356c85a44ee"
})

new Vue({
  router,
  store,
  vuetify,
  render: h => h(App)
}).$mount('#app')

fb.auth().onAuthStateChanged(user => {
  if (user) {
    store.commit('setUser', user.uid)
  } else {
    store.commit('removeUser')
  }
})

