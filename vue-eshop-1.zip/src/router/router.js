import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    component: () => import('@/views/Home')
  },
  {
    path: '/shop/:id',
    component: () => import('@/views/Shop')
  },
  {
    path: '/product/:id',
    name: 'productDetail',
    component: () => import('@/views/productDetail'),
    props: true
  },
  {
    path: '/cart',
    component: () => import('@/views/Cart')
  },
  {
    path: '/profile',
    name: 'profile',
    meta: { redirect: true },
    component: () => import('@/views/Profile'),
    children: [
      {
        path: 'details',
        component: () => import('@/components/profile/Details')
      },
      {
        path: 'orders',
        component: () => import('@/components/profile/Orders')
      },
      {
        path: 'address',
        component: () => import('@/components/profile/Address')
      }
    ]
  },
  {
    path: '/login',
    component: () => import('@/components/auth/login')
  },
  {
    path: '/register',
    component: () => import('@/components/auth/register')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
