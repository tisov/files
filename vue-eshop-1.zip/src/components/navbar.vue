<template>
  <v-app-bar
    color="deep-purple accent-4"
    dark app
  >
    <v-app-bar-nav-icon @click.stop="$emit('drawer')"
    ></v-app-bar-nav-icon>

    <v-toolbar-title>
      <router-link to="/">My shop</router-link>
    </v-toolbar-title>

    <v-spacer></v-spacer>
    
    <v-btn text icon link to="/cart" active-class="qwe"
      class="no-active"
    >
      <v-icon>mdi-cart</v-icon>
    </v-btn>
    
    <v-menu offset-y>
      <template v-slot:activator="{ on }">
        <v-btn text icon v-on="on" class="btn-profile">
          <v-icon>mdi-account-circle</v-icon>
        </v-btn>
      </template>
      <v-list >
        <v-list-item v-for="item in menuItems" :key="item.link"
          v-if="!!userId === item.auth"
        >
          <v-list-item-title>
            <v-list-item link :to="item.link">{{item.title}}</v-list-item>
          </v-list-item-title>
        </v-list-item>
        <v-list-item v-if="userId">
          <v-list-item-title>
            <v-list-item 
              @click="signOut"
            >Sign out</v-list-item>
          </v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>

  </v-app-bar>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  data() {
    return {
      menuItems: [
        { title: 'Account', link: '/profile/details', auth: true },
        { title: 'Sign in', link: '/login', auth: false },
        { title: 'Register', link: '/register', auth: false }
      ],
      menuItemsActive: []
    }
  },
  computed: {
    userId() {
      return this.$store.getters.getUserId
    }
  },
  methods: {
    async signOut() {
      try {
        await this.$store.dispatch('signOut')
        if (this.$route.path !== '/') {
          this.$router.push('/')
        }
      } catch (err) {

      }
    }
  },
  mounted() {

  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>
.v-btn--active.no-active::before
  opacity: 0 !important
</style>