<template>
  <v-card 
    class="mx-auto product"
    max-width="400"
  >
    <v-img
      class="white--text align-end product-img"
      max-height="150"
      :src="url" contain
    >
    </v-img>

    <v-card-subtitle class="py-2">
      <router-link to="/" @click.native="navigate"
        tag="span"
      >{{title}}</router-link>
    </v-card-subtitle>

    <v-card-actions>
      <v-btn color="deep-purple" dark small>
        Buy
      </v-btn>

      <v-btn color="deep-purple" outlined small
        @click="addToCart"
        :loading="cartLoading"
        :disabled="cartLoading"
      >
        Add to cart
      </v-btn>
      <v-spacer></v-spacer>
      <span>{{price}}$</span>
    </v-card-actions>
    
     <v-snackbar
      v-model="snackbar"
      :color="snackColor"
      top
    >
      {{ snackText }}
    </v-snackbar>
  </v-card>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  props: ['title', 'url', 'description', 'price', 'productId', 'catId'],
  data() {
    return {
      snackColor: '',
      snackText: '',
      snackbar: false,
      cartLoading: false
    }
  },
  methods: {
    async addToCart() {
      this.cartLoading = true
      try {
        await this.$store.dispatch('addToCart', {
          productId: this.productId,
          catId: this.catId
        })
        this.snackbar = true
        this.snackText = 'Item successfully added to cart'
        this.snackColor = 'success'

      } catch (err) {
        this.snackbar = true
        this.snackText = 'Something gone wrong'
        this.snackColor = 'red'
      }
      this.cartLoading = false
    },
    navigate() {
      this.$router.push({
        name: 'productDetail',
        params: { id: this.productId, catId: this.catId }
      })
    }
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass' scoped>
.v-card__subtitle
  font-weight: bold
  cursor: pointer
</style>