<template>
  <form class="form mt-4">
    <v-text-field
      v-model="$v.email.$model"
      label="E-mail"
      :error="$v.email.$error"
      :error-messages="emailErrors"
    ></v-text-field>
    <v-text-field
      v-model="$v.password.$model"
      label="Password"
      :error="$v.password.$error"
      :error-messages="passwordErrors"
      type="password"
    ></v-text-field>
    
    <div class="my-6"></div>
    
    <v-btn class="mr-4" @click="onSubmit"
      color="deep-purple" dark
    >submit</v-btn>
    <v-btn @click="onClear">clear</v-btn>
    
    <v-snackbar
      v-model="snackbar"
      color="error"
      top
    >
      {{ text }}
    </v-snackbar>
  </form>
</template>

<!-- ------------------------------------- -->
<script>
import { email, required, minLength } from 'vuelidate/lib/validators'
import formErrorMessages from '@/mixins/formErrorMessages.mixin'

export default {
  mixins: [formErrorMessages],
  data() {
    return {
      email: 'qwe@mail.com',
      password: '111111',
      text: '',
      snackbar: false
    }
  },
  methods: {
    async onSubmit() {
      this.$v.$touch()
      if (this.$v.$invalid) {
        return
      }

      let formData = {
        email: this.email,
        password: this.password
      }

      try {
        await this.$store.dispatch('signIn', formData)
        this.$router.push('/')
      } catch (err) {
        this.snackbar = true
        this.text = err.message
      }

    },
    onClear() {
      this.$v.$reset()
      this.email = ''
      this.password = ''
    }
  },
  validations: {
    email: {
      required, email
    },
    password: {
      required,
      minLength: minLength(6)
    }
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>
.form
  margin: 0 auto
  max-width: 400px
</style>