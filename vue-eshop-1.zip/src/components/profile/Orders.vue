<template>
  <v-container>
    <div class="v-row">
      <v-col cols="12" class="py-0">
        <!-- content title -->
        <div class="title">Orders</div>
      </v-col>
      <v-col cols="12" >
        <!-- table -->
        <v-simple-table>
          <template v-slot:default>
            <thead>
              <tr>
                <th class="text-left">#</th>
                <th class="text-left">Date</th>
                <th class="text-left">Title</th>
                <th class="text-left">Status</th>
                <th class="text-left">Amount</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(order, idx) in orders" :key="order.orderId">
                <td>{{ idx+1 }}</td>
                <td>{{ new Date(order.date).toDateString() }}</td>
                <td>{{ order.title }}</td>
                <td>{{ order.status }}</td>
                <td>{{ order.price }}</td>
              </tr>
            </tbody>
          </template>
        </v-simple-table>
      </v-col>
    </div>
  </v-container>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  data() {
    return {
      orders: []
    }
  },
  async created() {
    this.orders = await this.$store.dispatch('fetchOrders')
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>