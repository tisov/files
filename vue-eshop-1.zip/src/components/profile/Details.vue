<template>
  <v-container>
    <div class="v-row">
      <v-col cols="12" class="py-0">
        <div class="title">Profile details</div>
      </v-col>
      <v-col cols="12" class="d-flex justify-start">
        <form class="form mt-4">
          <v-text-field
            v-model="name"
            label="Name"
            :error="$v.name.$error"
            :error-messages="nameErrors"
          ></v-text-field>
          
          <div class="my-6"></div>
          
          <v-btn class="mr-4" @click="onSubmit"
            color="deep-purple" dark
          >change</v-btn>
        </form>
        
      </v-col>
    </div>
    
    <v-snackbar
      v-model="snackbar"
      color="success"
      top
    >
      {{ text }}
    </v-snackbar>
  </v-container>
</template>

<!-- ------------------------------------- -->
<script>
import { required } from 'vuelidate/lib/validators'
import formErrorMessages from '@/mixins/formErrorMessages.mixin'

export default {
  mixins: [formErrorMessages],
  data() {
    return {
      name: '',
      snackbar: false,
      text: 'Name successfull updated'
    }
  },
  computed: {

  },
  methods: {
    async onSubmit() {
      this.$v.$touch()
      if (this.$v.$invalid) {
        return
      }

      try {
        const newName = this.name
        await this.$store.dispatch('updateUserName', newName)
        this.name = this.$store.getters.getUserName
        this.snackbar = true
      } catch (err) {

      }
    }
  },
  async created() {
    await this.$store.dispatch('fetchUserName')
    this.name = this.$store.getters.getUserName
  },
  validations: {
    name: required
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass' scoped>
.form
  flex-basis: 300px
  margin: 0 !important
  margin-right: auto !important
</style>