<template>
  <v-container>
    <div class="v-row">
      <v-col cols="12" class="py-0 ">
        <div class="title">Address</div>
      </v-col>
      <v-col cols="12" class="d-flex justify-start">
        <form class="form mt-4">
          <v-text-field
            v-model="address"
            label="Your product reveive address"
          ></v-text-field>
          
          <div class="my-6"></div>
          
          <v-btn class="mr-4" @click="onSubmit"
            color="deep-purple" dark
          >change address</v-btn>
        </form>
        
      </v-col>
    </div>
    
    <v-snackbar
      v-model="snackbar"
      color="success"
      top
    >
      {{ text }}
    </v-snackbar>
  </v-container>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  data() {
    return {
      address: '',
      snackbar: false,
      text: 'Address successfull changed'
    }
  },
  methods: {
    async onSubmit() {

      try {
        const newAddress = this.address
        await this.$store.dispatch('updateUserAddress', newAddress)
        this.address = this.$store.getters.getUserAddress
        this.snackbar = true
      } catch (err) {

      }
    }
  },
  async created() {
    await this.$store.dispatch('fetchUserAddress')
    this.address = this.$store.getters.getUserAddress
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass' scoped>
.form
  flex-basis: 300px
  margin: 0 !important
  margin-right: auto !important
</style>