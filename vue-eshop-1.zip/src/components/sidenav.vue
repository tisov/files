<template>
  <v-navigation-drawer
    v-model="localDrawer"
    app
  >
    <v-list dense nav>
      <v-list-item>
        <v-list-item-title>Categories</v-list-item-title>
      </v-list-item>
      <v-divider></v-divider>
      <v-list-item
        v-for="cat in categories"
        :key="cat.title"
        link :to="`/shop/${cat.catId}`"
        @click="$emit('update')"
      >
        <v-list-item-icon>
          <v-icon>{{ cat.icon }}</v-icon>
        </v-list-item-icon>

        <v-list-item-content>
          <v-list-item-title>{{ cat.title }}</v-list-item-title>
        </v-list-item-content>
      </v-list-item>
    </v-list>
  </v-navigation-drawer>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  props: ['value', 'categories'],
  data() {
    return {
      localDrawer: this.drawer,
    }
  },
  watch: {
    value(val) {
      this.localDrawer = val
    },
    localDrawer(val) {
      this.$emit('input', this.localDrawer)
    }
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>