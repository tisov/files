<template>
  <div class="home" >
    <v-container>
      <h2 class="title">Recent products</h2>
      <v-row>
        <v-col v-for="product in products" :key="product.id" 
          cols="6" md="4"
        >
          <product :title="product.title"
            :url="product.imageUrl"
            :description="product.description"
            :price="product.price"
            :productId="product.productId"
            :catId="product.catId"
          ></product>
        </v-col>
        
      </v-row>
    </v-container>
  </div>
</template>

<!-- ------------------------------------- -->
<script>
import Product from '@/components/product'

export default {
  data() {
    return {
      products: []
    }
  },
  async created() {
    await this.$store.dispatch('fetchProducts')
    this.products = this.$store.getters.getProducts
  },
  components: {
    Product
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>