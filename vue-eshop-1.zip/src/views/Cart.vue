<template>
  <v-container>
    <v-simple-table>
      <template v-slot:default>
        <thead >
          <tr>
            <th class="text-left">#</th>
            <th class="text-left ">Title</th>
            <th class="text-left">Price</th>
            <th class="text-left">Remove</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(product, idx) in products" :key="product.name">
            <td>{{ idx+1 }}</td>
            <td class="font-weight-medium">
              <router-link to @click.native="navigate(
                product.productId, product.catId
              )">
                {{product.title}}
              </router-link>
            </td>
            <td>{{ product.price }}</td>
            <td><v-btn small  color="warning"
              @click="onRemove(product.productId)"
              :disabled="loading"
              :loading="loading"
            >x</v-btn></td>
          </tr>
        </tbody>
      </template>
    </v-simple-table>
    
    <v-btn color="success" small class="mt-4"
      @click="overlay = !overlay"
    >checkout</v-btn>
    
    <v-overlay :value="overlay" >
      <div class="checkout">
        <div class="address">
          <span class="headline d-block mb-4">Checkout</span>
          <span class="font-weight-bold">Send to: </span>
          <span>USA, NY, lincoln street, 233</span>
        </div>
        <div class="checkout-actions mt-2">
          <v-btn color="success" class="mr-2" small
            @click="onCheckout"
            :disabled="loadingOrder"
            :loading="loadingOrder"
          >order</v-btn>
          <v-btn color="warning" small @click="overlay = false">close</v-btn>
        </div>
      </div>
    </v-overlay>
  </v-container>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  data() {
    return {
      overlay: false,
      products: [],
      loading: false,
      loadingOrder: false
    }
  },
  methods: {
    navigate(prodId, catId) {
      this.$router.push({
        name: 'productDetail',
        params: { id: prodId, catId: catId }
      })
    },
    // Delete
    async onRemove(productId) {
      this.loading = true
      try {
        await this.$store.dispatch('deleteCartProduct', productId)
        this.products = this.products.filter(prod => {
          return prod.productId !== productId
        })
      } catch (err) { }
      this.loading = false
    },
    // Checkout
    async onCheckout() {
      this.loadingOrder = true
      try {
        await this.$store.dispatch('setOrder', this.products)
      } catch (err) { }

      this.clearCart()
      this.overlay = false
      this.loadingOrder = false
    },
    // Clear cart
    async clearCart() {
      try {
        await this.$store.dispatch('clearCart')
        this.products = []
      } catch (err) { }
    }
  },
  async created() {
    this.products = await this.$store.dispatch('fetchCartProducts')
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>
.checkout
  background-color: #f1f1f1
  padding: 20px
  color: #000
a
  text-decoration: none
  color: inherit !important
</style>