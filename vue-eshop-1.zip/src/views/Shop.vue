<template>
  <div class="shop" >
    <div class="shop_sidenav d-none d-sm-block">
      <v-list dense nav>
        <v-list-item>
          <v-list-item-title>Categories</v-list-item-title>
        </v-list-item>
        <v-divider></v-divider>
        <v-list-item
          v-for="cat in categories"
          :key="cat.title"
          link :to="`/shop/${cat.catId}`"
          @click="page = 1"
        >
          <v-list-item-icon>
            <v-icon>{{ cat.icon }}</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>{{ cat.title }}</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
      
    </div>
    <!-- shop content -->
    <div class="shop_content" >
      <v-container>
        <h2 class="category-title headline">{{currentCat.title}}</h2>
        <div class="paginate-info py-2 caption">
          Showing {{itemsPerPage}}, total {{productsByCategory.length}} Results
        </div>
        <v-row>
          <v-col cols="6" md="4" lg="3"
            v-for="product in pageProducts[pageProducts.length ? page - 1 : 0]" :key="product.productId"
          >
            <product :title="product.title"
              :description="product.description"
              :url="product.imageUrl"
              :price="product.price"
              :productId="product.productId"
              :catId="product.catId"
            ></product>
          </v-col>
        </v-row>
        <!-- pagination -->
        <v-pagination class="py-7"
          v-model="page"
          :length="length"
          @input="$router.push(`${$route.path}?page=${page}`)"
        ></v-pagination>
      </v-container>
    </div>
  </div>
</template>

<!-- ------------------------------------- -->
<script>
import product from '@/components/product'
import { chunk } from '@/mixins/functions'

export default {
  data() {
    return {
      page: +this.$route.query.page || 1,
      categories: [],
      currentCat: {},
      productsByCategory: [],
      pageProducts: [],
      itemsPerPage: 1,
      length: 1
    }
  },
  computed: {

  },
  watch: {
    '$route.params.id'(currentCatId) {
      this.currentCat = this.categories.find(cat => cat.catId === currentCatId)

      if (currentCatId === 'allItems') {
        this.productsByCategory = this.$store.getters.getProducts
      } else {
        this.productsByCategory = this.$store.getters.getProductsByCategory(
          currentCatId
        )
      }
      this.paginateInit()
    }
  },
  methods: {
    paginateInit() {

      this.pageProducts = chunk([...this.productsByCategory], this.itemsPerPage)
      this.length = this.pageProducts.length
    }
  },
  async created() {
    this.categories = await this.$store.dispatch('fetchCategories')
    let currentCatId = this.$route.params.id
    this.currentCat = this.categories.find(cat => {
      return cat.catId === currentCatId
    })

    await this.$store.dispatch('fetchProducts')

    if (currentCatId === 'allItems') {
      this.productsByCategory = this.$store.getters.getProducts
    } else {
      this.productsByCategory = this.$store.getters.getProductsByCategory(currentCatId)
    }

    // Paginate
    this.paginateInit()
  },
  components: {
    product
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>
.shop
  height: 100%
  display: flex
  &_sidenav
    flex: 0 0 220px
  &_content
    flex: 1 1 auto
    
</style>