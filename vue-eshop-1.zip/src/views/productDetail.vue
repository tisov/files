<template>
  <v-card
    class="mr-auto ma-4"
    max-width="344"
    outlined
  >
    <v-list-item three-line>
      <v-list-item-content>
        <v-list-item-title class="headline mb-1">
          {{product.title}}
        </v-list-item-title>
        <v-list-item-subtitle>{{product.description}}</v-list-item-subtitle>
      </v-list-item-content>

      <v-list-item-avatar
        tile
        size="80"
      >
        <v-img :src="product.imageUrl"></v-img>
      </v-list-item-avatar>
    </v-list-item>

    <v-card-actions>
      <v-btn text outlined>Buy</v-btn>
      <v-btn text >Add to cart</v-btn>
      <v-spacer></v-spacer>
      <span>{{product.price}}</span>
    </v-card-actions>
  </v-card>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  data() {
    return {
      product: {}
    }
  },
  computed: {
    productId() {
      return this.$route.params.id
    },
    catId() {
      return this.$route.params.catId
    }
  },
  async created() {
    this.product = await this.$store.dispatch('fetchProductById', {
      productId: this.productId,
      catId: this.catId
    })
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>