<template>
  <div class="profile">
    <div class="profile-list">
      <v-list height="100%" color="deep-purple lighten-5">
        <v-subheader>My accont</v-subheader>
        <v-list-item
          v-for="item in items"
          :key="item.link"
          link :to="item.link"
        >
          <v-list-item-icon>
            <v-icon v-text="item.icon"></v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title v-text="item.title"></v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </div>
    
    <div class="profile-content">
      <router-view></router-view>
    </div>
  </div>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  data() {
    return {
      items: [
        { title: 'Profile details', link: '/profile/details', icon: 'mdi-account' },
        { title: 'Orders', link: '/profile/orders', icon: 'mdi-bookmark-outline' },
        { title: 'Address', link: '/profile/address', icon: 'mdi-map-marker' },
      ]
    }
  },
  computed: {

  },
  async created() {
    // await this.$store.dispatch('fetchUserData')
  },
  beforeMount() {
    if (this.$route.meta.redirect) {
      this.$router.push(this.items[0].link)
    }
  },
  mounted() {

  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>
.profile
  display: flex
  height: 100%
  &-list
    flex: 0 0 250px
    height: 100%
  &-content
    flex: 1 0 auto
</style>