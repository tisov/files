<template>
  <v-app>
    <navbar @input="drawer = !drawer"
      :links="links"
    ></navbar>
    
    <nav-drawer v-model="drawer"
      :links="links"
    ></nav-drawer>
    
    <v-content class="grey lighten-4 mx-4 mb-4">
      <router-view></router-view>
    </v-content>
    
    <v-snackbar  v-model="snackbar.show" top
      :color="snackbar.color"
    >
      {{ snackbar.message }}
    </v-snackbar>
  </v-app>
</template>

<!-- ------------------------------------- -->
<script>
import Navbar from '@/components/Navbar'
import NavDrawer from '@/components/NavDrawer'

export default {
  data() {
    return {
      // snackbar: false,
      drawer: false,
      links: [
        { title: 'Dashboar', icon: 'dashboard', path: '/' },
        { title: 'My Projects', icon: 'folder', path: '/projects' },
        { title: 'Team', icon: 'person', path: '/team' }
      ]
    }
  },
  computed: {
    snackbar() {
      return this.$store.getters.getSnackbar
    }
  },
  components: {
    Navbar,
    NavDrawer
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>
