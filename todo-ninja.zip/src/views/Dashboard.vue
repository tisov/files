<template>
  <div class="dashboard">
    <h1 class="subtitle-1 grey--text">Dashboard</h1>
    
    <v-container class="my-4">
      <v-row justify-start class="mb-3">
        <v-tooltip top>
          <template v-slot:activator="{on}">
            <v-btn small text color="grey" @click="sortBy('title')"
              v-on="on"
            >
              <v-icon small left>folder</v-icon>
              <span class="caption text-lowercase">By project name</span>
            </v-btn>
          </template>
          <span>Sort by project name</span>
        </v-tooltip>
        
        <v-tooltip top>
          <template v-slot:activator="{on}">
            <v-btn small text color="grey" @click="sortBy('person')"
              v-on="on"
            >
              <v-icon small left>person</v-icon>
              <span class="caption text-lowercase">By person</span>
            </v-btn>
          </template>
          <span>Sort by poject author</span>
        </v-tooltip>
      </v-row>
      
      <v-progress-linear v-if="loading"
        indeterminate
        color="primary"
      ></v-progress-linear>
      
      <v-card flat v-else-if="paging.itemsChunk.length !== 0"
        v-for="proj in paging.itemsChunk[paging.currentPage-1]" 
        :key="proj.projectId"
        :class="`project ${proj.status}`"
      >
        <v-row wrap class="pa-3">
          <v-col md="6">
            <div class="caption grey--text">Project title</div>
            <div>{{proj.title}}</div>
          </v-col>
          <v-col sm="4" md="2">
            <div class="caption grey--text">Person</div>
            <div>{{proj.person}}</div>
          </v-col>
          <v-col sm="4" md="2">
            <div class="caption grey--text">Due by</div>
            <div>{{proj.due}}</div>
          </v-col>
          <v-col sm="4" md="2" class="d-flex justify-end">
            <v-chip small :class="`${proj.status} white--text my-2 caption`">
              {{ proj.status }}
            </v-chip>
          </v-col>
        </v-row>
      </v-card>
    
      <div v-else-if="!paging.itemsChunk.length"
        class="text-center grey--text my-5 subtitle-1"
      >
        Ooops! You don't have any projects yet.
      </div>
    
      <v-pagination class="mt-4"
        v-model="paging.currentPage"
        :length="paging.totalPages"
        @input="pagingHadle"
      ></v-pagination>
    </v-container>
  </div>
</template>

<!-- ------------------------------------- -->
<script>
import { chunk } from '@/utils/functions'
import fb from 'firebase/app'

export default {
  data() {
    return {
      loading: false,
      paging: {
        currentPage: +this.$route.query.page || 1,
        itemsPerPage: 2,
        itemsChunk: [],
        totalPages: 0
      }
    }
  },
  computed: {
    projects() {
      return this.$store.getters.projects
    }
  },
  watch: {
    projects(newVal, oldVal) {
      this.pagingInit()
    }
  },
  methods: {
    sortBy(prop) {
      this.paging.itemsChunk[this.paging.currentPage - 1]
        .sort((a, b) => a[prop] < b[prop] ? -1 : 1)
    },
    pagingInit() {
      this.paging.itemsChunk = chunk([...this.projects], this.paging.itemsPerPage)
      this.paging.totalPages = this.paging.itemsChunk.length
    },
    pagingHadle() {
      this.$router.push(`${this.$route.path}?page=${this.paging.currentPage}`)
    }
  },
  async mounted() {
    this.loading = true
    if (this.projects.length === 0) {
      try {
        await this.$store.dispatch('fetchProjects')
        // this.pagingInit()
      } catch (err) {
        this.$store.commit('setSnackbar', {
          color: 'error',
          message: err
        })
      }
    }
    this.pagingInit()
    this.loading = false

    // await this.$store.dispatch('fetchProjects')
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>
.project.complete
  border-left: 4px solid #3CD1C2

.project.ongoing
  border-left: 4px solid orange

.project.overdue
  border-left: 4px solid tomato

.v-chip.complete
  background: #3cd1c2 !important

.v-chip.ongoing
  background: #ffaa2c !important

.v-chip.overdue
  background: #f83e70 !important

</style>
