export default {
  state: {
    snackbar: {}
  },
  mutations: {
    setSnackbar(state, payload) {
      state.snackbar = {
        show: true,
        color: payload.color || '',
        message: payload.message || ''
      }
    }
  },
  getters: {
    getSnackbar: state => state.snackbar
  }
}