import Vue from 'vue'
import Vuex from 'vuex'
import fb from 'firebase/app'
import snackbar from './snackbar'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    projects: []
  },
  mutations: {
    setProjects(state, payload) {
      if (payload.length > 1) {
        state.projects.push(...payload)
      } else {
        state.projects.push(payload[0])
      }
    },
    clearProjects(state) {
      state.projects = []
    }
  },
  actions: {
    // Add project
    async addProject({ }, payload) {
      let res = await fb.firestore().collection('projects').add({
        ...payload
      })

    },
    // Fetch projects
    async fetchProjects({ commit }) {
      let res = await new Promise(res => {
        let projects = []
        fb.firestore().collection('projects')
          .onSnapshot(snapshot => {
            snapshot.docChanges.forEach(change => {
              if (change.type === 'added') {
                projects.push({
                  ...change.doc.data(),
                  projectId: change.doc.id
                })
                res('')
              }
            })
            commit('setProjects', projects)
            projects = []
          })
      })
    }
    // Fetch user projects
    
  },
  getters: {
    projects(state) {
      return state.projects
    }
  },
  modules: {
    snackbar
  }
})
