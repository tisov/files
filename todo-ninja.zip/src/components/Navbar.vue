<template>
  <v-app-bar dense app flat color="grey lighten-4">
    <v-app-bar-nav-icon class="grey--text"
      @click.stop="$emit('input')"
    ></v-app-bar-nav-icon>
    <v-toolbar-title class="text-uppercase grey--text">
      <span class="font-weight-light">todo</span>
      <span>ninja</span>
    </v-toolbar-title>
    <v-spacer></v-spacer>
    
    <!-- navbar menu -->
    <v-menu offset-y>
      <template v-slot:activator="{ on }">
        <v-btn text color="grey" v-on="on">
          <v-icon left>expand_more</v-icon>
          <span>Menu</span>
        </v-btn>
      </template>
      
      <v-list dense>
        <v-list-item v-for="link in links"
          :key="link.title"
          link :to="link.path"
        >
          <v-list-item-title class="font-weight-medium">
            {{ link.title }}
          </v-list-item-title>
        </v-list-item>
      </v-list>
      
      <!-- <v-list>
        <v-list-tile v-for="link in links" 
          :key="link.title" 
          router :to="link.path"
        >
          <v-list-tile-title>{{ link.title }}</v-list-tile-title>
        </v-list-tile>
      </v-list> -->
    </v-menu>
    
    <v-btn color="grey" text>
      <span>sign out</span>
      <v-icon right>exit_to_app</v-icon>
    </v-btn>
  </v-app-bar>
</template>

<!-- ------------------------------------- -->
<script>
export default {
  props: ['links'],
  data() {
    return {

    }
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>