<template>
  <v-dialog max-width="600" v-model="dialog">
    <template v-slot:activator="{ on }">
      <v-btn depressed tile color="success" v-on="on">
        add new project
      </v-btn>
    </template>
    <v-card :loading="loading" :disabled="loading">
      <v-card-title class="pt-2 px-3">
        <h2 class="subtitle-1">Add a New Project</h2>
      </v-card-title>
      <v-card-text class="px-3">
        <v-form ref="form">
          <v-text-field v-model="title" label="Title"
            dense outlined
            :rules="inputRules"
          ></v-text-field>
          <v-textarea v-model="content" label="Information"
            dense rows="2"
            outlined
            :rules="inputRules"
          ></v-textarea>
          <!-- date picker menu -->
          <v-menu v-model="menu"
            max-width="290px"
            min-width="290px"
          >
            <template v-slot:activator="{ on }">
              <v-text-field
                v-model="formattedDate"
                label="Due date"
                prepend-icon="event"
                v-on="on"
                :rules="inputRules"
              ></v-text-field>
            </template>
            <v-date-picker v-model="due" no-title @input="menu = false"></v-date-picker>
          </v-menu>
          
          <v-spacer></v-spacer>
          <v-btn depressed tile @click="submit" class="success mx-0 mt-3">
            Add Project
          </v-btn>
        </v-form>
        
      </v-card-text>
    </v-card>
  </v-dialog>
</template>

<!-- ------------------------------------- -->
<script>
import format from 'date-fns/format'

export default {
  data() {
    return {
      loading: false,
      dialog: false,
      title: 'qwe',
      content: 'qwe',
      menu: false,
      due: '',
      inputRules: [
        v => v.length >= 3 || 'Minimum length is 3'
      ]
    }
  },
  methods: {
    submit() {
      if (this.$refs.form.validate()) {
        this.loading = true
        let formData = {
          title: this.title,
          content: this.content,
          due: this.due,
          person: 'The Net Ninja',
          status: 'ongoing'
        }

        this.$store.dispatch('addProject', formData)
          .then(() => {
            this.$store.commit('setSnackbar', {
              color: 'success',
              message: 'New project successfully created'
            })
            this.dialog = false
          })
          .catch((err) => {
            this.$store.commit('setSnackbar', {
              color: 'error',
              message: err
            })
          })
          .finally(() => {
            this.loading = false
          })
      }
    }
  },
  computed: {
    formattedDate() {
      return this.due ? format(new Date(this.due), 'Do MMM yyyy') : ''
    }
  },
  created() {

  }

}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>