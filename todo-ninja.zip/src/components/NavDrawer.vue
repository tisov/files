<template>
  <v-navigation-drawer app 
    :value="value" 
    @input="$emit('input', $event)"
    color="primary"
    dark
  >
    <v-row justify="center">
      <v-col cols="12" class="d-flex flex-column align-center">
        <v-avatar size="80">
          <img class="text--center" src="/avatar-1.png">
        </v-avatar>
        <p class="white--text subtitle-1 my-1">The Net Ninja</p>
      </v-col>
    </v-row>
    <v-row justify="center">
      <v-col cols="auto">
        <add-project-modal></add-project-modal>
      </v-col>
    </v-row>
    <v-list>
      <v-list-item v-for="link in links" :key="link.title" 
        link :to="link.path"
      >
        <v-list-item-icon>
          <v-icon>{{link.icon}}</v-icon>
        </v-list-item-icon>

        <v-list-item-content>
          <v-list-item-title>{{link.title}}</v-list-item-title>
        </v-list-item-content>
      </v-list-item>
    </v-list>
  </v-navigation-drawer>
</template>

<!-- ------------------------------------- -->
<script>
import AddProjectModal from '@/components/AddProjectModal'

export default {
  props: ['value', 'links'],
  data() {
    return {

    }
  },
  components: {
    AddProjectModal
  }
}
</script>

<!-- ------------------------------------- -->
<style lang='sass'>

</style>