function chunk(arr, size = 1) {
  let length = Math.ceil(arr.length / size)
  let newArr = []
  for (let i = 0; i < length; i++) {
    newArr.push(arr.splice(0, size))
  }
  return newArr
}

export { chunk }