import Vue from 'vue'
import App from './App.vue'
import router from './router/router'
import store from './store/store'
import fb from 'firebase/app'
import 'firebase/auth'
import 'firebase/firestore'
import vuetify from './plugins/vuetify'

Vue.config.productionTip = false
let app = null

fb.initializeApp({
  apiKey: "AIzaSyDjg5KsPjOzANWQYpvqACsfbyABQYmGXOA",
  authDomain: "todo-ninja-3272.firebaseapp.com",
  databaseURL: "https://todo-ninja-3272.firebaseio.com",
  projectId: "todo-ninja-3272",
  storageBucket: "todo-ninja-3272.appspot.com",
  messagingSenderId: "205654819355",
  appId: "1:205654819355:web:b998e6d3f52ed54a3daebe"
})

fb.auth().onAuthStateChanged(user => {
  if (!app) {
    app = new Vue({
      router,
      store,
      vuetify,
      render: function(h) { return h(App) }
    }).$mount('#app')

  }
})

